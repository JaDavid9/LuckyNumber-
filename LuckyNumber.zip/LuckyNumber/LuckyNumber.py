import random
import emoji


level = input("Enter the level you want! You can choose between level1, level2, level3")

if level == 'level1':
    n = random.randint(1,50)
    counter = 10
elif level == 'level2':
    n = random.randint(1,100)
    counter = 8
elif level == 'level3':
    n = random.randint(1,200)
    counter = 5
else:
    print("You have not chosen the right level")

while counter > 0:

    counter -= 1
    m = int(input("Enter a number: "))
    if m == n:
        print(emoji.emojize("You guessed it! :party_popper: "))
        print(f'The requested number was {n}')
        break
    elif m > n:
        print(f"The requested number is less than {m}")
    elif m < n:
        print(f"The requested number is greater than {m}")
if counter == 0:
    print(emoji.emojize("You lost! :disappointed_face:"))
    print (f'The requested number was {n}')


